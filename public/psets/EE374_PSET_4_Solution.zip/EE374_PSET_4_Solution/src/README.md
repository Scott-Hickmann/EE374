# Installing

In the root dir:

* Run `npm i`
* Run `tsc`
* Run `npm run start`
